# 16DOF 站立模型：队友使用包

本包可独立回放，不需要原训练目录、STL 网格、CUDA、mjlab 或 PyTorch。
建议在 Windows x64 / Python 3.12 上使用；回放使用 CPU ONNX 推理和 MuJoCo 3.8.1。
所有安装缓存、虚拟环境和回放结果都放在解压目录内。

## 最快使用

在本目录打开 PowerShell，执行：

```powershell
# 仅首次：创建本目录虚拟环境并安装回放依赖（需已安装 Python 3.12）
.\setup.ps1
# 弹出 MuJoCo 窗口，回放最佳站立策略 60 秒
.\play.ps1
# 不弹窗，验证 20 秒仿真
.\play.ps1 -Headless -Seconds 20
```

若 PowerShell 禁止运行脚本，在当前 PowerShell 窗口先执行
`Set-ExecutionPolicy -Scope Process Bypass`。模型演示可直接播放 `model_500_delay1.mp4`。

Linux 或 macOS 可在自行准备的 Python 环境中安装 `requirements.txt`，然后运行：

```sh
python tools/replay_stand_16dof.py --onnx model_500.onnx --contract model_500.replay.json --headless --seconds 20
```

本次实际验证平台为 Windows，其他平台的图形窗口需自行配置。

## 文件用途

| 文件 | 用途 |
|---|---|
| `model_500.onnx` | 推荐使用的策略；53 维观测输入 `obs`，16 维动作输出 `actions` |
| `model_500.replay.json` | 明确输入关节顺序、默认站姿、动作缩放和偏置、滤波、时步等契约 |
| `replay_model.mjb` | 与已验证独立回放一致的 MuJoCo 编译模型，已包含网格 |
| `tools/replay_stand_16dof.py` | 正确构造观测、应用动作与延迟滤波的完整范例 |
| `model_500.pt` | 原训练检查点；包含 actor/critic 等状态，供后续训练工程使用 |
| `results/` | 原始评估 JSON、训练参数、TensorBoard 数据及报告 |
| `MANIFEST.json` | 压缩包内各文件的 SHA-256 校验值 |

已有 ONNX Runtime 项目可直接加载 ONNX：输入形状 `[batch,53]`、`float32`，输出
`[batch,16]`。观测按机身角速度×0.25、投影重力、零速度指令、12 个腿关节相对
位置、12 个腿关节速度×0.05、4 个轮速度×0.05、上次原始动作排列。实际腿顺序为
FR、FL、RL、RR，每腿 hip/thigh/calf；必须结合契约中的默认关节位置和动作映射。

ONNX 输出需经过契约定义的缩放、偏置、延迟与两抽头滤波后才能作为控制目标，
不能把原始输出当电机力矩。参考回放程序已完整处理这些步骤。

## 本次训练结果

2026-11-25 完成 600 轮、512 环境 PPO 训练（7,372,800 环境步），从第 300、400、
500、599 轮中选出第 500 轮。轻微初始扰动下，64 环境各运行 20 秒均未摔倒；
稳态机身高度约 0.37790 m，平均角速度约 0.00114 rad/s，腿部平均绝对力矩约
2.023 N·m。64 环境各接受 3 次 0.30 m/s 水平速度脉冲，亦未摔倒。

ONNX 与 PyTorch 推理最大绝对误差约 9.54e-7。原生 MuJoCo 0、1、2 步延迟回放
各 20 秒均通过。模型只训练了零速度指令的站立，不具备已验证的行走能力。
上述结论限于所测仿真条件；真机需另做电机方向/限幅/零位及控制器验证。

注意：源 MJCF 是 16 个 actuator，训练编译模型保留源 actuator 并增加 mjlab servo，
合计 32 个 MuJoCo 控制槽。这是本次既有模型的实际状态，回放程序已匹配；
真机适配时应按 16 个真实关节和电机重新设计映射，不要照搬 32 槽数组。

`.pt` 不包含训练环境程序。本包覆盖直接使用和回放策略，继续训练需对接原训练
代码及 `results/params/` 中的配置，不能直接用仓库根目录的 go2w 任务替代。
