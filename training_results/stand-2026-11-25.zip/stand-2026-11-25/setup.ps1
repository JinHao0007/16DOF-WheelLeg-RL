$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
$env:TMP = Join-Path $PSScriptRoot ".cache\tmp"
$env:TEMP = $env:TMP
$env:TMPDIR = $env:TMP
$env:PIP_CACHE_DIR = Join-Path $PSScriptRoot ".cache\pip"
$env:PYTHONDONTWRITEBYTECODE = "1"
New-Item -ItemType Directory -Force -Path $env:TMP, $env:PIP_CACHE_DIR | Out-Null
if (-not (Test-Path ".venv\Scripts\python.exe")) {
    py -3.12 -m venv .venv
    if ($LASTEXITCODE -ne 0) { throw "Install 64-bit Python 3.12 first." }
}
& .\.venv\Scripts\python.exe -m pip install --cache-dir $env:PIP_CACHE_DIR -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw "Dependency installation failed." }
Write-Host "Ready: run .\play.ps1"
