param(
    [switch]$Headless,
    [double]$Seconds = 60,
    [ValidateSet(0, 1, 2)][int]$Delay = 1,
    [string]$PythonExe = ""
)
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
if (-not $PythonExe) { $PythonExe = Join-Path $PSScriptRoot ".venv\Scripts\python.exe" }
if (-not (Test-Path $PythonExe)) { throw "Run .\setup.ps1 first." }
$env:TMP = Join-Path $PSScriptRoot ".cache\tmp"
$env:TEMP = $env:TMP
$env:TMPDIR = $env:TMP
$env:MPLCONFIGDIR = Join-Path $PSScriptRoot ".cache\mpl"
$env:PYTHONIOENCODING = "utf-8"
$env:PYTHONDONTWRITEBYTECODE = "1"
New-Item -ItemType Directory -Force -Path $env:TMP | Out-Null
$replayArgs = @(
    "tools\replay_stand_16dof.py",
    "--onnx", "model_500.onnx", "--contract", "model_500.replay.json",
    "--seconds", "$Seconds", "--delay", "$Delay"
)
if ($Headless) { $replayArgs += "--headless" }
& $PythonExe @replayArgs
if ($LASTEXITCODE -ne 0) { throw "Replay failed." }
