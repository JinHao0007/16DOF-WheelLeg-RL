"""Replay a standing ONNX policy using its saved MuJoCo contract.

The compiled model, actual runtime joint order, default pose and two-tap
action filter come from evaluate_stand_16dof.py --export-replay.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
for name in ("TMP", "TEMP", "TMPDIR"):
    os.environ[name] = str(ROOT / ".cache" / "tmp")
os.environ["MPLCONFIGDIR"] = str(ROOT / ".cache" / "mpl")

import mujoco
import numpy as np
import onnxruntime as ort


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--onnx", type=Path, required=True)
    ap.add_argument("--contract", type=Path, required=True)
    ap.add_argument("--seconds", type=float, default=20.0)
    ap.add_argument("--delay", type=int, choices=(0, 1, 2), default=1)
    ap.add_argument("--headless", action="store_true")
    ap.add_argument("--video", type=Path)
    args = ap.parse_args()
    contract = json.loads(args.contract.read_text(encoding="utf-8"))
    model_path = args.contract.parent / contract["model"]
    if hashlib.sha256(model_path.read_bytes()).hexdigest() != contract["model_sha256"]:
        raise ValueError("Replay model hash does not match the saved contract")
    model = mujoco.MjModel.from_binary_path(str(model_path))
    if not np.isclose(model.opt.timestep, contract["physics_dt"]):
        raise ValueError("Physics timestep differs from training")
    data = mujoco.MjData(model)
    data.qpos[:] = np.asarray(contract["initial_qpos"])
    data.qvel[:] = 0.0
    mujoco.mj_forward(model, data)

    def joint_ids(names):
        ids = [mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_JOINT, name) for name in names]
        if any(jid < 0 for jid in ids):
            raise ValueError(f"Unknown joint in contract: {names}")
        return np.asarray(ids)

    legs = joint_ids(contract["leg_obs_joints"])
    wheels = joint_ids(contract["wheel_obs_joints"])
    leg_q = model.jnt_qposadr[legs]
    leg_v = model.jnt_dofadr[legs]
    wheel_v = model.jnt_dofadr[wheels]
    default_leg = np.array([
        contract["default_joint_pos"][name.split("/")[-1]]
        for name in contract["leg_obs_joints"]
    ])
    root_joint = int(np.flatnonzero(model.jnt_type == mujoco.mjtJoint.mjJNT_FREE)[0])
    root_body = int(model.jnt_bodyid[root_joint])
    terms = []
    start = 0
    for term in contract["action_terms"]:
        targets = joint_ids(term["joints"])
        controls = []
        for target in targets:
            matches = np.flatnonzero(model.actuator_trnid[:, 0] == target)
            # The compiled mjlab model keeps its source actuator and adds the
            # EntityCfg servo. Both motors participate in qfrc_actuator; feed
            # the same target to every matching actuator for parity.
            if len(matches) < 1:
                raise ValueError(f"No actuator for joint id {target}")
            controls.append(matches.tolist())
        count = len(targets)
        terms.append({
            "start": start,
            "count": count,
            "controls": controls,
            "scale": np.asarray(term["scale"]),
            "offset": np.asarray(term["offset"]),
            "weights": np.asarray(term["weights"]),
            "history": [np.zeros(count) for _ in range(3)],
            "previous_delayed": np.zeros(count),
        })
        start += count

    options = ort.SessionOptions()
    options.intra_op_num_threads = 1
    options.inter_op_num_threads = 1
    session = ort.InferenceSession(
        str(args.onnx), sess_options=options, providers=["CPUExecutionProvider"]
    )
    input_name = session.get_inputs()[0].name
    last_action = np.zeros(16, dtype=np.float32)
    duration_steps = max(1, round(args.seconds / contract["control_dt"]))
    metrics = []

    def step_once():
        nonlocal last_action
        local_velocity = np.zeros(6)
        mujoco.mj_objectVelocity(
            model, data, mujoco.mjtObj.mjOBJ_BODY, root_body, local_velocity, 1
        )
        rotation = data.xmat[root_body].reshape(3, 3)
        gravity = rotation.T @ np.array([0.0, 0.0, -1.0])
        obs = np.concatenate([
            local_velocity[:3] * 0.25,
            gravity,
            np.zeros(3),
            data.qpos[leg_q] - default_leg,
            data.qvel[leg_v] * 0.05,
            data.qvel[wheel_v] * 0.05,
            last_action,
        ]).astype(np.float32)[None]
        if obs.shape != (1, 53) or not np.isfinite(obs).all():
            raise RuntimeError("Invalid 53D observation during standalone replay")
        action = session.run(None, {input_name: obs})[0][0]
        if action.shape != (16,) or not np.isfinite(action).all():
            raise RuntimeError("Invalid 16D policy action")
        for term in terms:
            begin = term["start"]
            raw = action[begin:begin + term["count"]].copy()
            term["history"].append(raw)
            term["history"].pop(0)
            delayed = term["history"][2 - args.delay]
            weights = term["weights"]
            filtered = weights[0] * delayed + weights[1] * term["previous_delayed"]
            term["previous_delayed"] = delayed.copy()
            targets = term["offset"] + term["scale"] * filtered
            for index, actuator_ids in enumerate(term["controls"]):
                data.ctrl[actuator_ids] = targets[index]
        last_action = action.astype(np.float32)
        for _ in range(contract["decimation"]):
            mujoco.mj_step(model, data)
        mujoco.mj_forward(model, data)
        gravity = data.xmat[root_body].reshape(3, 3).T @ np.array([0.0, 0.0, -1.0])
        metrics.append((float(data.xpos[root_body, 2]), float(-gravity[2])))

    renderer = None
    video_writer = None
    camera = mujoco.MjvCamera()
    camera.type = mujoco.mjtCamera.mjCAMERA_FREE
    camera.distance = 2.4
    camera.azimuth = 125
    camera.elevation = -18
    camera.lookat[:] = data.xpos[root_body]
    if args.video:
        import imageio_ffmpeg

        args.video.parent.mkdir(parents=True, exist_ok=True)
        renderer = mujoco.Renderer(model, height=480, width=640)
        video_writer = imageio_ffmpeg.write_frames(
            str(args.video), (640, 480), fps=25, codec="libx264", quality=7
        )
        video_writer.send(None)

    def render_video(index):
        if renderer is not None and index % 2 == 0:
            camera.lookat[:] = data.xpos[root_body]
            renderer.update_scene(data, camera=camera)
            video_writer.send(renderer.render().tobytes())

    try:
        if args.headless:
            for index in range(duration_steps):
                step_once()
                render_video(index)
        else:
            from mujoco import viewer as mj_viewer

            with mj_viewer.launch_passive(model, data) as viewer:
                for index in range(duration_steps):
                    if not viewer.is_running():
                        break
                    tick = time.perf_counter()
                    step_once()
                    viewer.sync()
                    render_video(index)
                    time.sleep(max(0.0, contract["control_dt"] - (time.perf_counter() - tick)))
    finally:
        if video_writer is not None:
            video_writer.close()
        if renderer is not None:
            renderer.close()
    values = np.asarray(metrics)
    result = {
        "onnx": str(args.onnx.resolve()),
        "contract": str(args.contract.resolve()),
        "control_steps": len(values),
        "delay_steps": args.delay,
        "finite": bool(np.isfinite(data.qpos).all()),
        "mean_height_m": float(values[:, 0].mean()),
        "height_std_m": float(values[:, 0].std()),
        "mean_upright": float(values[:, 1].mean()),
        "min_upright": float(values[:, 1].min()),
    }
    output = args.onnx.with_name(f"{args.onnx.stem}_native_replay_delay{args.delay}.json")
    output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
